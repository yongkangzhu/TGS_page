﻿
$(function () {
    console.log();
});

function table_initial() {
    $('#tgstb').bootstrapTable({
        url: 'data1.json'
    });
}